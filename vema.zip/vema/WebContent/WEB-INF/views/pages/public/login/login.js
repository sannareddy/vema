angular.module('vema')
	   .controller('loginController',function(){
		   var login=this;
		   login.msg="Login Controller";
	   });