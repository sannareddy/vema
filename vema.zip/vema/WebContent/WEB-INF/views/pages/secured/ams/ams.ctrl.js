angular.module('vema')
	   .controller('amsController',function(){
		   var ams=this;
		   ams.msg="AMS Controller";
	   });