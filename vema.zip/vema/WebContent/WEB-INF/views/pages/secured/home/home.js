angular.module('vema')
	   .controller('homeController',function(){
		   var home=this;
		   home.msg="Home Controller";
	   });